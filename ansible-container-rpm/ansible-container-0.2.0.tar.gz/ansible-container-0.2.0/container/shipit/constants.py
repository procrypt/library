# -*- coding: utf-8 -*-


# TODO - Make these configurable?

SHIPIT_PATH = 'ansible'
SHIPIT_CONFIG_PATH= "shipit_config"
SHIPIT_PLAYBOOK_PREFIX = "shipit"
SHIPIT_ROLES_DIR = 'roles'
